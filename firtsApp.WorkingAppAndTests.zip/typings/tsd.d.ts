
/// <reference path="angular2/angular2.d.ts" />
