// Type definitions for Angular 2
// Project: http://angular.io/
// Definitions by: angular team <https://github.com/angular/>
// Definitions: https://github.com/borisyankov/DefinitelyTyped

// Angular 2 distributes typings in our NPM package.
// To get the typings, simply:
// $ npm install angular2
// and use TypeScript 1.6.2 or later.
//
// Note that TypeScript must be configured with
// --moduleResolution node
// which is the default when --module commonjs
